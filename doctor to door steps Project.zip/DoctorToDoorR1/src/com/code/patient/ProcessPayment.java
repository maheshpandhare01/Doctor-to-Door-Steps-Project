package com.code.patient;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dbcon.ConnectionProvider;

/**
 * Servlet implementation class ProcessPayment
 */
@WebServlet("/ProcessPayment")
public class ProcessPayment extends HttpServlet {
	private static final long serialVersionUID = 1L;
static Connection con=null;
	
	public void init(ServletConfig config) throws ServletException {
		
		try {
			con=ConnectionProvider.getConnection();
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String id=request.getParameter("id");
		
		try 
		{
			PreparedStatement ps=con.prepareStatement("UPDATE `appoinment_details` SET  `fees_status`='Received' where `id`='"+id+"'");
			int r = ps.executeUpdate();
			if(r>0)
			{
				System.out.println("Request Update");
				response.sendRedirect("patient_checkPrescription.jsp?id="+id+"&payment=done");
			}
			else
			{
				System.out.println("Update Fail");
				response.sendRedirect("patient_checkPrescription.jsp?id="+id+"&fpayment=fail");
			}
		}
		catch (Exception e) 
		{
			System.out.println("Exc "+e);
		
		}
		
	
	}


}