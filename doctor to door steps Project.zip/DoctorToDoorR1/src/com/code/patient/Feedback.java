package com.code.patient;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dbcon.ConnectionProvider;

/**
 * Servlet implementation class Feedback
 */
@WebServlet("/Feedback")
public class Feedback extends HttpServlet {
	private static final long serialVersionUID = 1L;

	static Connection con=null;
	
	public void init(ServletConfig config) throws ServletException {
		
		try {
			con=ConnectionProvider.getConnection();
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("POst method call ");
		String id=request.getParameter("id");
		String feedback=request.getParameter("feedback");
		String rating=request.getParameter("rating");
		String dr_id=request.getParameter("dr_id");
		String p_id=request.getParameter("p_id");
	
		
		try 
		{
			PreparedStatement ps=con.prepareStatement("INSERT INTO `feedback_details`(`app_id`, `p_id`, `dr_id`, `feedback`, `rating`) VALUES ('"+id+"','"+p_id+"','"+dr_id+"','"+feedback+"','"+rating+"')");
			System.out.println("PS "+ps);
			int r = ps.executeUpdate();
			if(r>0)
			{
				PreparedStatement ps1=con.prepareStatement("UPDATE `appoinment_details` SET feedback='Update' where id='"+id+"'");
				System.out.println("PS1 "+ps1);
				int r1 = ps1.executeUpdate();
				if(r1>0)
				{
					System.out.println("Feedback Submit ");
					response.sendRedirect("p_viewBApp.jsp?feedback=sent");
				}
			}
			else
			{
				System.out.println("Feedback Fails");
				response.sendRedirect("p_viewBApp.jsp?feedback=sent");
			}
		}
		catch (Exception e)
		{
			System.out.println("Exc "+e);
		}
	}
}