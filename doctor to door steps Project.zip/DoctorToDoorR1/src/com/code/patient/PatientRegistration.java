package com.code.patient;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dbcon.ConnectionProvider;

/**
 * Servlet implementation class PatientRegistration
 */
@WebServlet("/PatientRegistration")
public class PatientRegistration extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Connection con;
	public void init(ServletConfig config) throws ServletException 
	{
		try 
		{
			con=ConnectionProvider.getConnection();
		} 
		catch (Exception e) 
		{
			System.out.println("Exception "+e);
		}
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	
		String fname= request.getParameter("fname");
		String mname= request.getParameter("mname");
		String lname= request.getParameter("lname");
		
		String dob= request.getParameter("dob");
		String gender= request.getParameter("gender");
		String mobile= request.getParameter("mobile");
		String adhar_id= request.getParameter("adhar_id");
		String address= request.getParameter("address");
		String email= request.getParameter("email");
		String password= request.getParameter("password");
		
		System.out.println("Email ID: "+email);
		System.out.println("Password :  "+password);
		
		DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd");
		Date dateobj = new Date();
		String reg_date=df1.format(dateobj);
		
		
		try 
		{
			PreparedStatement ps1 = con.prepareStatement("INSERT INTO `patient_details`(`fname`, `mname`, `lname`, `dob`, `gender`, `mobile`, `adhar_id`, `address`, `email`, `password`, `reg_date`) VALUES ('"+fname+"','"+mname+"','"+lname+"','"+dob+"','"+gender+"','"+mobile+"','"+adhar_id+"','"+address+"','"+email+"','"+password+"','"+reg_date+"')");
			int i=ps1.executeUpdate();
			if (i>0) 
			{
				System.out.println("Registration Done");
				response.sendRedirect("patientLogin.jsp?reg=done");

			}
			else 
			{
				System.out.println("Registration fail");
				response.sendRedirect("patientRegistration.jsp?fail=done");
			}
		}
		catch (Exception e) 
		{
			System.out.println("Exc "+e);
		}
	}
}