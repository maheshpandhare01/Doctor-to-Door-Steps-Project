package com.code.patient;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.HashMap;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.code.global.GlobalFunction;
import com.dbcon.ConnectionProvider;

/**
 * Servlet implementation class ProvideFeedback
 */
@WebServlet("/ProvideFeedback")
public class ProvideFeedback extends HttpServlet {
	private static final long serialVersionUID = 1L;
static Connection con=null;
	
	public void init(ServletConfig config) throws ServletException {
		
		try {
			con=ConnectionProvider.getConnection();
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("POst method call ");
		
		HttpSession session=request.getSession();
		String p_email= session.getAttribute("email").toString();
		
		String id=request.getParameter("ap_id");
	
		String feedback=request.getParameter("feedback");
		String rating=request.getParameter("rating");
		String dr_id=request.getParameter("dr_id");
		GlobalFunction gf=new GlobalFunction();
		
		
		HashMap<String, String> dr_Details = gf.getDr_Details(dr_id);
		String acc_type = dr_Details.get("acc_type");
		
		
		
		
		try 
		{
			PreparedStatement ps=con.prepareStatement("INSERT INTO `feedback_details`(`app_id`, `p_id`, `dr_id`, `feedback`, `rating`,`fd_for`) VALUES ('"+id+"','"+p_email+"','"+dr_id+"','"+feedback+"','"+rating+"','"+acc_type+"')");
			System.out.println("PS "+ps);
			int r = ps.executeUpdate();
			if(r>0)
			{
				if(acc_type.equals("Doctor"))
				{
					PreparedStatement ps1=con.prepareStatement("UPDATE `appoinment_details` SET feedback='Update' where id='"+id+"'");
					System.out.println("PS11 "+ps1);
					int r1 = ps1.executeUpdate();
					if(r1>0)
					{
						System.out.println("Feedback Submit ");
						response.sendRedirect("p_viewBApp.jsp?feedback=sent");
					}
				}else if(acc_type.equals("PathologyLab"))
				{
					PreparedStatement ps1=con.prepareStatement("UPDATE `pathology_report` SET feedback_status='Update' where id='"+id+"'");
					System.out.println("PS22 "+ps1);
					int r1 = ps1.executeUpdate();
					if(r1>0)
					{
						System.out.println("Feedback Submit ");
						response.sendRedirect("pt_viewUploadReport.jsp?feedback=sent");
					}
				}
			}
			else
			{
				System.out.println("Feedback Fails");
				response.sendRedirect("p_viewBApp.jsp?feedback=sent");
			}
		}
		catch (Exception e)
		{
			System.out.println("Exc "+e);
		}
	}
}