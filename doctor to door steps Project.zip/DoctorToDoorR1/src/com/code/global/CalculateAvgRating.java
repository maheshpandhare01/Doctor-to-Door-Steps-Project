package com.code.global;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashSet;

import com.dbcon.ConnectionProvider;

public class CalculateAvgRating 
{

	static Connection con=ConnectionProvider.getConnection();
	
	public double getAvarageRating(String dr_id)
	{
		double avg=0;
		
		try 
		{
			PreparedStatement ps=con.prepareStatement("SELECT * FROM `feedback_details` where dr_id='"+dr_id+"'");
			ResultSet rs=ps.executeQuery();
			int count=1;
			int total_rating=0;
			while(rs.next())
			{
				total_rating=total_rating+Integer.parseInt(rs.getString("rating"));
				++count;
			}
			avg=total_rating/count;
		} catch (Exception e) 
		{
			System.out.println("Exc getDQualification "+e);
		}
		return avg;
	}
}
