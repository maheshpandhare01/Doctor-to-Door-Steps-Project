package com.code.global;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import com.dbcon.ConnectionProvider;

public class GlobalFunction 
{
	
	static Connection con=ConnectionProvider.getConnection();
	
	public HashSet<String> getDQualification(String acc_type)
	{
		HashSet<String> qua=new HashSet<>();
		
		try 
		{
			PreparedStatement ps=con.prepareStatement("Select DISTINCT(qualification) from doctor_details where acc_type='"+acc_type+"'");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				qua.add(rs.getString(1));
			}
			
		} catch (Exception e) 
		{
			System.out.println("Exc getDQualification "+e);
		}
		
		return qua;
		
		
	}
	
	public ArrayList<String> getLastPrescription(String user_email, String dr_id)
	{
		ArrayList<String> app_ids=new ArrayList<>();
		
		try 
		{
			PreparedStatement ps=con.prepareStatement("Select * from appoinment_details where user_email='"+user_email+"' AND d_id='"+dr_id+"' AND status='Check' ORDER BY id DESC");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				app_ids.add(rs.getString("id"));
			}
			
		} catch (Exception e) 
		{
			System.out.println("Exc getDQualification "+e);
		}
		
		return app_ids;
		
		
	}
	
	
	
	public HashSet<String> getDAreaName(String acc_type)
	{
		HashSet<String> qua=new HashSet<>();
		try 
		{
			PreparedStatement ps=con.prepareStatement("Select DISTINCT(area_name) from doctor_details where acc_type='"+acc_type+"'");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				qua.add(rs.getString(1));
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Exc getarea Name ");
			
		}
		return qua;
	}
	
	
	public HashSet<String> getDrSpecialCategory()
	{
		HashSet<String> qua=new HashSet<>();
		try 
		{
			PreparedStatement ps=con.prepareStatement("SELECT DISTINCT(specialty_name) FROM doctor_specialties ORDER BY specialty_name ASC");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				qua.add(rs.getString(1));
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Exc speciality Name ");
			
		}
		return qua;
	}
	
	public HashSet<String> getAvailableDrSpecialist(String acc_type)
	{
		HashSet<String> qua=new HashSet<>();
		try 
		{
			PreparedStatement ps=con.prepareStatement("SELECT DISTINCT(speciality) FROM doctor_details where acc_type='"+acc_type+"' ORDER BY speciality ASC");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				qua.add(rs.getString(1));
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Exc speciality Name ");
			
		}
		return qua;
	}
	
	
	public HashMap<String,String> getDr_Details(String id)
	{
		HashMap<String,String> dr_details=new HashMap<>();
		
		try 
		{
			PreparedStatement ps=con.prepareStatement("SELECT * FROM `doctor_details` where id='"+id+"'");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{ 
				dr_details.put("id", rs.getString("id"));
				dr_details.put("fname", rs.getString("fname"));
				dr_details.put("mname", rs.getString("mname"));
				dr_details.put("lname", rs.getString("lname"));
				
				dr_details.put("dob", rs.getString("dob"));
				dr_details.put("gender", rs.getString("gender"));
				dr_details.put("full_name", rs.getString("fname")+" "+rs.getString("mname")+" "+rs.getString("lname"));
				dr_details.put("mobile", rs.getString("mobile"));
				dr_details.put("adhar_id", rs.getString("adhar_id"));
				dr_details.put("email", rs.getString("email"));
				dr_details.put("address", rs.getString("address"));
				dr_details.put("area_name", rs.getString("area_name"));
				dr_details.put("qualification", rs.getString("qualification"));
				dr_details.put("acc_type", rs.getString("acc_type"));
			}
			
		} catch (Exception e) 
		{
			System.out.println("Exc "+e);
		}
		return dr_details;
	}
	

	
	
	public HashMap<String,String> getPatientDetails(String id)
	{
		HashMap<String,String> p_details=new HashMap<>();
		
		try 
		{
			PreparedStatement ps=con.prepareStatement("SELECT * FROM `patient_details` where email='"+id+"'");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{ 
				p_details.put("fname", rs.getString("fname"));
				p_details.put("mname", rs.getString("mname"));
				p_details.put("lname", rs.getString("lname"));
				p_details.put("gender", rs.getString("gender"));
				p_details.put("dob", rs.getString("dob"));
				p_details.put("mobile", rs.getString("mobile"));
				p_details.put("address", rs.getString("address"));
				p_details.put("full_name", rs.getString("fname")+" "+rs.getString("mname")+" "+rs.getString("lname"));
			}
			
		} catch (Exception e) 
		{
			System.out.println("Exc "+e);
		}
		return p_details;
	}
	
	public HashMap<String,String> getPathologyReport(String req_id)
	{
		HashMap<String,String> p_details=new HashMap<>();
		
		try 
		{
			PreparedStatement ps=con.prepareStatement("SELECT * FROM `pathology_report` where id='"+req_id+"'");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{ 
				p_details.put("id", rs.getString("id"));
				p_details.put("patient_id", rs.getString("patient_id"));
				p_details.put("pname", rs.getString("pname"));
				p_details.put("dr_id", rs.getString("dr_id"));
				p_details.put("app_id", rs.getString("app_id"));
				p_details.put("time_slot", rs.getString("time_slot"));
				p_details.put("app_date", rs.getString("app_date"));
				p_details.put("refer_by_dr_id", rs.getString("refer_by_dr_id"));
				p_details.put("feedback_status", rs.getString("feedback_status"));
			}
			
		} catch (Exception e) 
		{
			System.out.println("Exc "+e);
		}
		return p_details;
	}
	
	
	
	public HashMap<String,String> getLabReport(String user_email)
	{
		HashMap<String,String> report_required=new HashMap<String,String>();
		
		try 
		{
			PreparedStatement ps=con.prepareStatement("SELECT * FROM `appoinment_details` where lab_report_sts='waiting' AND user_email='"+user_email+"' AND status='Check'");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{ 
				report_required.put(rs.getString("id"),rs.getString("d_id")+","+rs.getString("pname")+"--"+rs.getString("lab_report"));
				
			}
			
		} catch (Exception e) 
		{
			System.out.println("Exc "+e);
		}
		return report_required;
	}
	
	
	
	public HashMap<String,String> getDrBusyTime(String d_id,String app_date)
	{
		HashMap<String,String> free_time_slot=new HashMap<>();
		free_time_slot.put("10:00AM To 11:00AM","1");
		free_time_slot.put("11:00AM To 12:00PM","2");
		free_time_slot.put("12:00PM To 01:00PM","3");
		free_time_slot.put("01:00PM To 02:00PM","4");
		free_time_slot.put("02:00PM To 03:00PM","5");
		free_time_slot.put("03:00PM To 04:00PM","6");
		free_time_slot.put("04:00PM To 05:00PM","7");
		free_time_slot.put("05:00PM To 06:00PM","8");
		free_time_slot.put("06:00PM To 07:00PM","9");
		free_time_slot.put("07:00PM To 08:00PM","10");
		
		try 
		{
			PreparedStatement ps=con.prepareStatement("SELECT * FROM `appoinment_details` where d_id='"+d_id+"' AND app_date='"+app_date+"' AND status='Accept'");
			System.out.println("PS "+ps);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{ 
				free_time_slot.remove(rs.getString("time_slot"));
			}
		}
		catch (Exception e) 
		{
			System.out.println("Exc Dr Busy Time "+e);
		}	
		
		return free_time_slot;
	}

	public HashMap<String,String> getLabBusyTime(String d_id,String app_date)
	{
		HashMap<String,String> free_time_slot=new HashMap<>();
		
		free_time_slot.put("10:00AM To 11:00AM","1");
		free_time_slot.put("11:00AM To 12:00PM","2");
		free_time_slot.put("12:00PM To 01:00PM","3");
		free_time_slot.put("01:00PM To 02:00PM","4");
		free_time_slot.put("02:00PM To 03:00PM","5");
		free_time_slot.put("03:00PM To 04:00PM","6");
		free_time_slot.put("04:00PM To 05:00PM","7");
		free_time_slot.put("05:00PM To 06:00PM","8");
		free_time_slot.put("06:00PM To 07:00PM","9");
		free_time_slot.put("07:00PM To 08:00PM","10");
		
		try 
		{
			PreparedStatement ps=con.prepareStatement("SELECT * FROM `pathology_report` where dr_id='"+d_id+"' AND app_date='"+app_date+"' AND status='Accept'");
			System.out.println("PS "+ps);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{ 
				free_time_slot.remove(rs.getString("time_slot"));
			}
		} catch (Exception e) 
		{
			System.out.println("Exc Dr Busy Time "+e);
		}	
		return free_time_slot;
	}
	
	public HashMap<String,String> getAppointmentDetails(String id)
	{
		HashMap<String,String> app_details=new HashMap<>();
		
		try 
		{
			PreparedStatement ps=con.prepareStatement("SELECT * FROM `appoinment_details` where id='"+id+"'");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{ 
				app_details.put("user_email", rs.getString("user_email"));
				app_details.put("d_id", rs.getString("d_id"));
				app_details.put("lab_report", rs.getString("lab_report"));
				app_details.put("lab_report_sts", rs.getString("lab_report_sts"));
				
				app_details.put("id", rs.getString("id"));
				app_details.put("app_date", rs.getString("app_date"));
				app_details.put("time_slot", rs.getString("time_slot"));
				app_details.put("pname", rs.getString("pname"));
				app_details.put("symptons", rs.getString("symptons"));
				app_details.put("pname", rs.getString("pname"));
				
				app_details.put("fees", rs.getString("fees"));
				app_details.put("fees_status", rs.getString("fees_status"));
			}
			
		} catch (Exception e) 
		{
			System.out.println("Exc "+e);
		}
		return app_details;
	}
	


	public HashMap<String,String> getPathologyReportDetail(String id)
	{
		HashMap<String,String> rep_details=new HashMap<>();
		
		try 
		{
			PreparedStatement ps=con.prepareStatement("SELECT * FROM `pathology_report` where id='"+id+"'");
			System.out.println("PS   "+ps);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{ 
				rep_details.put("patient_id", rs.getString("patient_id"));
				rep_details.put("pname", rs.getString("pname"));
				rep_details.put("dr_id", rs.getString("dr_id"));
				rep_details.put("app_id", rs.getString("app_id"));
				rep_details.put("refer_by_dr_id", rs.getString("refer_by_dr_id"));
				rep_details.put("app_date", rs.getString("app_date"));
				rep_details.put("time_slot", rs.getString("time_slot"));
				rep_details.put("feedback_status", rs.getString("feedback_status"));
				
			}
			else
			{
				System.out.println("Flase Execure ");
			}
			
		} catch (Exception e) 
		{
			System.out.println("Exc "+e);
		}
		
		return rep_details;
	}
	
	
	public long getAge(String dob)
	{
        LocalDate startDate = LocalDate.parse(dob);
        LocalDate endDate = LocalDate.now();
        // Calculate the difference in years
        long age = ChronoUnit.YEARS.between(startDate, endDate);
        return age;
	}
	
	public static void main(String[] args) {
		
		GlobalFunction gf=new GlobalFunction();
		HashSet<String> qual =gf.getDQualification("");
		System.out.println("Qua "+qual);
		
	}

}
