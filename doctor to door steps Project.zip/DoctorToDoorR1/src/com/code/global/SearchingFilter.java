package com.code.global;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.dbcon.ConnectionProvider;

public class SearchingFilter 
{
	static Connection con=ConnectionProvider.getConnection();
	
	public ResultSet getSearchDoctorDetails(String speciality,String quall,String acc_type,String dr_area_name)
	{
		ResultSet rs=null;
		try 
		{
		    String query = "SELECT * FROM doctor_details WHERE 1=1";

		    if (speciality != null && !speciality.isEmpty()) {
	            query += " AND speciality = ?";
	        }
	        if (quall != null && !quall.isEmpty()) {
	            query += " AND qualification = ?";
	        }
	        if (acc_type != null && !acc_type.isEmpty()) {
	            query += " AND acc_type = ?";
	        }
	        if (dr_area_name != null && !dr_area_name.isEmpty()) {
	            query += " AND area_name = ?";
	        }
	      
			PreparedStatement pstmt = con.prepareStatement(query);
	        
			int paramIndex = 1;
            if (speciality != null && !speciality.isEmpty()) {
                pstmt.setString(paramIndex++, speciality);
            }
            if (quall != null && !quall.isEmpty()) {
                pstmt.setString(paramIndex++, quall);
            }
            if (acc_type != null && !acc_type.isEmpty()) {
                pstmt.setString(paramIndex++, acc_type);
            }
            if (dr_area_name != null && !dr_area_name.isEmpty()) {
                pstmt.setString(paramIndex++, dr_area_name);
            }
            System.out.println("PS "+pstmt);
            rs = pstmt.executeQuery();
		} catch (Exception e) 
		{
			System.out.println("Exc "+e);
		}
		return rs;
	}
	

}
